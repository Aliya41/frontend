import React, { Component } from 'react'
import { BrowserRouter as Router,Routes,Route } from 'react-router-dom';
import JoinerForm from './components/Administrator/JoinerForm/JoinerForm';
import DisplayJoiner from './components/Administrator/JoinerForm/DisplayJoiner';
import OnboardForm from './components/Administrator/OboardForm/OnbaordForm';
import DisplayOnboard from './components/Administrator/OboardForm/DisplayOnboard';
import DashBoard2 from './components/Administrator/DashBoard2';
import Demo from './components/demo';
function App() {
  return (
     
    <Router>
    <Routes>
    <Route  element={<JoinerForm/>} path="/JoinerForm"   ></Route>
    <Route  element={<DisplayJoiner/>} path="/DisplayJoiner"   ></Route>
    <Route  element={<OnboardForm/>} path="/"   ></Route>
    <Route  element={<DisplayOnboard/>} path="/DisplayOnboard"   ></Route>
    <Route  element={<DashBoard2/>} path="/DashBoard2"   ></Route>
    <Route  element={<Demo/>} path="/Demo"   ></Route>
    </Routes>
    </Router>
  );
}

export default App;
